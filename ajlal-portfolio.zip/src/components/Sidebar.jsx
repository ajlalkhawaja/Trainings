import React from 'react';

function Sidebar() {
  return <div></div>;
}

export default Sidebar;
